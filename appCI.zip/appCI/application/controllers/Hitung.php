<?
/*
Nama    : AL EKSAN DITYA PRASETYA
Nim     : 411201002


*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Hitung extends CI_Controller{
    
    function _construct(){
        parent:: _construct();
            $this -> load -> helper(array('url','form'));
    }

    public function index() // fungsi default yang dijalankan
    {
        $this->load->view('menu_hitung'); // menampilkan menu hitung pada view

    }
    function Perkalian()// fungsi untuk melakukan perkalian antar 2 variabel
    {
        $data['d1']=(int) $this ->input->post('d1',true);
        $data['d1']=(int) $this ->input->post('d2',true);
        $data['hasil']= $data['d1']*$data['d2'];
        $this ->load->view('perkalian',$data);
    }

    function Pembagian() //fungsi untuk melakukan pembagian
    {  
        $data['d1']=(int) $this ->input->post('d1',true);
        $data['d1']=(int) $this ->input->post('d2',true);
            if ($data['d2']>0)
                $data['hasil']= $data['d1']/$data['d2'];
            else
                $data['hasil']='error,d2 tidak boleh 0';
                $this ->load->view('pembagian',$data);
    }
