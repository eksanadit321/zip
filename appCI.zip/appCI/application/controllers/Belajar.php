<?php
defined('BASEPATH') OR exit ('No direct script allowed');

class Belajar extends CI_Controller{
    function _construct(){
            parent::_construct();
        }
        public function jalan()
        {
            echo "ini method jalan pada controller belajar.";
            echo "cara membuat controller pada CI";
        }
        public function mundur()
        {
            // echo "ini method mundur pada controller belajar";
            $this->load->view('vbelajar');
        }
}
