<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Cmahasiswa extends CI_Controller
{
    function _construct()
    {
        parent:: _construct();
        $this->load->model('Mdatamahasiswa');
        $this->load->helper('url');
    }
    function index()
    {
        $data['tb_mahasiswa'] = $this->Mdatamahasiswa->tampil_mhs()->result();
        $this->load->view('vtampil',$data);
    }
    function tambah_mhs()
    {
        $this->load->view('vtambah');
    }
    function tambah_aksi()
    {
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');
        $jurusan = $this->input->post('jurusan');

        $data = array(
                        'nim'=>$nim,
                        'nama'=>$nama,
                        'jurusan'=>$jurusan
        );
        $this->Mdatamahasiswa->input_mhs($data,'tb_mahasiswa');
        redorect('cmahasiswa/index');
    }
}