<?php

defined('BASEPATH') OR exit ('Np direct script access allowed');
class Barang Extends CI_Controller{
    public function _construct()
    {
        parent::_construct();
        $this->load->model('Mbarang');
    }
    
    public function index()
    {
        $data['data_barang'] = $this->Mbarang->getBarang();
        $this->load->view('vbarang',$data);
    }
}