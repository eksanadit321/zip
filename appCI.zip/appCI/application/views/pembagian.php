<h1>Perkalian</h1>
    <div id="body">
        <p>Silahkan masukkan data </p>
        <?php echo form_open('hitung/pembagian'); ?>
        <?php echo form_input('d1',' ');?> /
        <?php echo form_input('d2',' ');?> <br>
        </br>
        <?php echo form_submit('submit','Hitung');?>
        <?php echo form_close();?>
        Hasil: <?php echo $hasil; ?>
        <br>
<?php echo anchor('hitung','<br> Menut Utama');?>