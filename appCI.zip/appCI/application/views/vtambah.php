<!DOCTYPE html>
<html>
<head>
    <title>CRUD</title>
</head>
<body>
<center>
    <h1>Membuat CRUD dengan CodeIgniter | Pemrograman Website </h1>
    <h3>Tambah data baru </h3>
</center>
<form action="<?php echo base_url().'index.php/Cmahasiswa/tambah_aksi'; ?>" method="post">
    <table style ="margin: 20px auto;">
        <tr>
            <td>NIM</td>
            <td><input type="text" name="nim"></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="nim"></td>
        </tr>
        <tr>
            <td>Jurusan</td>
            <td><input type="text" name="nim"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="text" name="nim"></td>
        </tr>

    
</body>
</html>