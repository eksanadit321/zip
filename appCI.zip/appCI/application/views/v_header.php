<!DOCTYPE html>
<html lang="en">
<head>
    <title>Template css di CI</title>
    <link rel ="stylesheet" href="<?php echo base_url()?>assets/css/style.css">
</head>
<body>
    <div id="wrapper">
        <header>
            <hgroup>
                <h1>Header<h1>
                <h3>belajar menggunakan template</h3>
        </hgroup>
        <nav>
            <ul>
                <li><a href=<?php echo base_url().'index.php/web' ?>">Home</li>
                <li><a href=<?php echo base_url().'index.php/web' ?>">About</li>
            </ul>
        </nav>
        <div class="clear"></div>
        </header>
</body>
</html>