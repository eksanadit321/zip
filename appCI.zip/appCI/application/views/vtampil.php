<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <link rel="stylesheet" href="">
</head>
<body>
    <center><h1>Membuat CRUD dengan CodeIgniter | Pemrograman Website</h1></center>
    <center><?php echo anchor('Cmahasiswa/tambah','Tambah Data');?></center>
    <table style="margin:20px auto;" border="1">
        <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Jurusan</th>
            <th>AKSI</th>
        </tr>
        <?php
        $no=1;
        foreach ($tb_mahasiswa as $mhs){
        ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td><?php echo $mhs->nim?></td>
            <td><?php echo $mhs->nama ?></td>
            <td><?php echo $mhs->Jurusan ?></td>
            <td>
                <!--anchor untuk membuat hyperlink dan harus men-load url di construct -->
                <?php echo anchor('Cmahasiswa/edit/'.$mhs->id,'EDIT');?>
                <?php echo anchor('Cmahasiswa/hapus/'.$mhs->id,'HAPUS');?>
            </td>
        </tr>
        <?php } ?>

        }
</body>
</html>