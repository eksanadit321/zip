<!DOCTYPE html>
<html lang="en">
<head>
 
    <title>View Coba Parsing</title>
</head>
<body>
    <h2><?php echo $judul; ?></h2>
    <h3><?php echo $tutorial; ?><h3>
    
</body>
</html>