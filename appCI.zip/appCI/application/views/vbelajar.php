<html lang="en">
<head>
   
    <title>Cara Membuat View pada CodeIgniter</title>
</head>
<body>

<h1>Belajar Membuat View Pada CodeIgniter </h1>
<h2>Ini merupakan view dari vbelajar.php</h2>
<h3>ini adalah isi view yang di tampilkan pada controller belajar,method mundur</h3>
    
</body>
</html>