<footer>
    
    <a href="#"><strong>Footer</strong> $copy 20202 </a>

</footer>