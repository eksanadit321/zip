<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang</title>
</head>
<body>
    <h2>Daftar Barang </h2>
<table  border ="1">
    <tr>
        <th> No</th>
        <th> Merk</th>
        <th> Warna</th>
        <th> Stok</th>
    </tr>
    </php
        $no = 1;
        for($i=0; $i<count($data_barang); $i++){
            echo '<tr>';
                echo'<td>'.$no.'</td>';
                echo'<td>'.$data_barang[$i]['merk'].'</td>';
                echo'<td>'.$data_barang[$i]['warna'].'</td>';
                echo'<td>'.$data_barang[$i]['stok'].'</td>';
            echo '</tr>';
            $no++;
        }
</table>
</body>
</html>