<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mbarang extends CI_Model{
    public function getBarang()
    {
        return array(
            array(
                'merk => canon',
                'warna' => 'hitam',
                'stock' => '100'
            ),
            array(
                'merk'=> 'Hp',
                'warna'=>'Putih',
                'stok'=> '50'
            ),
        );
    }
}