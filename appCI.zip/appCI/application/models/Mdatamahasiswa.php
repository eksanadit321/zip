<?php
/**
 * 
 */
class Mdatamahasiswa extends CI_model
{
    
    function tampil_mhs()
    {
        return $this->db->get('tb_mahasiswa');
    }
}